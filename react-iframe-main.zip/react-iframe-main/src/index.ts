export { ReactIframe, default } from './ReactIframe';
export type { ReactIframeProps } from './types';
